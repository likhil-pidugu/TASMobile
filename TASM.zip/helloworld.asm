.MODEL SMALL
.STACK 100h

.DATA
HelloMessage DB 'Hello, world!',13,10,'$' ; The string to display, followed by carriage return (13), line feed (10), and '$' terminator.

.CODE
.STARTUP                         ; Simplifies program startup for .EXE files

mov ah, 9                        ; DOS function call 9h (Display String).
mov dx, OFFSET HelloMessage      ; Load the address of the message into DX.
int 21h                          ; Call DOS interrupt to display the string.

mov ah, 4ch                      ; DOS function call 4Ch (Terminate Program).
int 21h                          ; Call DOS interrupt to exit.

END                              ; Marks the end of the program
