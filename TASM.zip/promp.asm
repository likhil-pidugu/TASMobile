.MODEL SMALL
.STACK 100h

.DATA
; --- Messages ---
MsgDefault DB 'Hello, World!',13,10
            DB 'Type "mypromo author" or "mypromo promo" for more info.$'

MsgAuthor  DB 'Author: Jane Doe',13,10
            DB 'LinkedIn: linkedin.com
            DB 'Instagram: @janedoe_codes$'

MsgPromo   DB 'Check out my latest project at github.com
            DB 'Follow me for more assembly fun!$'

MsgUnknown DB 'Unknown command. Use "author" or "promo".$'

; --- Comparison Keywords ---
KeyAuthor  DB 'author'
KeyPromo   DB 'promo'

.CODE

; --- Function to print a string (Input: DX = offset of string) ---
PrintString PROC
    mov ah, 9h
    int 21h
    ret
PrintString ENDP

; --- Function to compare strings (Input: SI = str1, DI = str2, CX = length) ---
; Returns ZF=1 if equal, ZF=0 if not equal
CompareString PROC
    cld                  ; Clear direction flag (forward comparison)
    repe cmpsb           ; Repeat compare strings while equal (ECX times)
    ret
CompareString ENDP

.STARTUP

    ; Get command-line argument from PSP at address 81h
    ; PSP:80h holds length byte, PSP:81h starts the actual argument string
    mov si, 81h          ; Source index points to the argument in the PSP
    
    ; Determine length of the argument provided
    mov cl, es:[80h]     ; ES is already set to PSP segment by .STARTUP
    xor ch, ch           ; Clear CH
    mov cx, cx           ; CX now holds the length of the argument

    ; If length is 0 (no argument), show default message and exit
    cmp cx, 0
    je ShowDefault

    ; --- Check if argument matches "author" ---
    mov di, OFFSET KeyAuthor
    ; We only need to compare up to 6 characters (length of 'author')
    mov cx, 6
    call CompareString
    je ShowAuthor        ; If ZF set (equal), jump to author section

    ; --- Check if argument matches "promo" ---
    mov di, OFFSET KeyPromo
    ; We only need to compare up to 5 characters (length of 'promo')
    mov cx, 5
    call CompareString
    je ShowPromo         ; If ZF set (equal), jump to promo section

    ; If no matches, show unknown message
    jmp ShowUnknown

ShowDefault:
    mov dx, OFFSET MsgDefault
    call PrintString
    jmp ExitProgram

ShowAuthor:
    mov dx, OFFSET MsgAuthor
    call PrintString
    jmp ExitProgram

ShowPromo:
    mov dx, OFFSET MsgPromo
    call PrintString
    jmp ExitProgram

ShowUnknown:
    mov dx, OFFSET MsgUnknown
    call PrintString
    jmp ExitProgram

ExitProgram:
    mov ah, 4ch          ; Terminate Program
    int 21h              ; Call DOS interrupt to exit

END
